package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MissionImpl implements Mission {

    @Override
    public void explore(State state, Collection<Explorer> explorers) {
        ArrayList<String> exhibits = (ArrayList<String>) state.getExhibits();
        int index = 0;
        for (Explorer explorer : explorers) {
            while (explorer.canSearch() && exhibits.size() > 0) {
                explorer.search();
                explorer.getSuitcase().getExhibits().add(exhibits.get(index));
                exhibits.remove(index);
                index++;
            }
        }
    }
}
